/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.banksystem;

/**
 *
 * @author user
 */
public class BankSystem {

    public static void main(String[] args) {
       
    }
}
